Title:
The Wailing Tavern D&D Wiki README

Data & File Overview:
D&D webpage.html
D&D CSS.css

This is the main homepage of the D&D Wiki, users will be
able to log in and search the wiki for any D&D related content.

The Header has some navigation options along with a search bar
The Body has the main navigation buttons, Will be adding images
inside the box and align it to how the wireframe was presented.
The Footer has Quick Links/Copyright Information

